<script setup>
import CountryName from "@/components/CountryName.vue";
</script>

<template>
<CountryName />

</template>

<style scoped>

</style>
